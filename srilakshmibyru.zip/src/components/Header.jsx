import React from "react";

function Header() {
  return (
    <header>
      <h1>REACT.JS&JS</h1>
    </header>
  );
}

export default Header;